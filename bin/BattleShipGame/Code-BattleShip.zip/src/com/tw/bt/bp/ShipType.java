package com.tw.bt.bp;

/**
 * Ship Type supported
 * @author puagarwa
 *
 */
public enum ShipType {
	
	BETTLESHIP

}
