package com.tw.bt.api;

/**
 * Interface for Ship Strength
 * @author puagarwa
 *
 */
public interface ShipStrength {
	//To get Ship Strength
	public Integer getShipStrength();

}
